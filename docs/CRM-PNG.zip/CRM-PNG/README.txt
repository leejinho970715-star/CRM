IONE CRM 리뉴얼 · 2026-10-05
45장의 전체 화면 PNG
01 영업활동 단독, 02 영업활동 통합, 이후 전체 CRM 44개 화면
Pretendard / White & Neutral / Calm Density / Thin Border / Bento
샘플 데이터 UI 시안입니다.
https://leejinho970715-star.github.io/CRM/